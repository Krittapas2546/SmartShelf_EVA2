# LMS Configuration
LMS_BASE_URL = "http://43.72.20.146"
LMS_ENDPOINT = "/api/sf/productioncontrol/api/LocationSystem/CheckCorrectShelf"
LMS_API_KEY = "pdcAPI"

# Timeout settings
LMS_TIMEOUT = 10.0

# Other settings
LMS_RETRY_COUNT = 1
